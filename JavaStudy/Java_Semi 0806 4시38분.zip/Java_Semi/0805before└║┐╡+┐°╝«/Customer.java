public class Customer
{
	public static void main(String[] args)
	{
		try
		{
			Machine.startMenu();
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		


	}

}